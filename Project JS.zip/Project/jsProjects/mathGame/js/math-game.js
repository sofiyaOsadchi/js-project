const btnCheck = document.getElementById('btn-check');
const inputResult = document.getElementById('input-result');
const pExercise = document.getElementById('exercise');
const pFeedback = document.getElementById('feedback'); // Add a paragraph for feedback
const pScore = document.getElementById('score'); // Add a paragraph for score

let score = 0; // Initialize score

const operators = ['+', '-', '*', '/']; // Array of operators

const random = (min, max) =>
    min + Math.round(Math.random() * (max - min));

function genExercise(range = 10) {
    const operator = operators[random(0, operators.length - 1)]; // Randomly select an operator
    const rand1 = random(1, range);
    const rand2 = (operator === '/') ? random(1, range) : random(1, range); // Ensure non-zero divisor

    let exercise = '';
    let result;

    switch (operator) {
        case '+':
            exercise = `${rand1} + ${rand2}`;
            result = rand1 + rand2;
            break;
        case '-':
            exercise = `${rand1} - ${rand2}`;
            result = rand1 - rand2;
            break;
        case '*':
            exercise = `${rand1} * ${rand2}`;
            result = rand1 * rand2;
            break;
        case '/':
            rand1 = rand1 * rand2; 
            exercise = `${rand1} / ${rand2}`;
            result = rand1 / rand2
            break;
    }

    return { exercise, result };
}

function updateExercise() {
    const { exercise, result } = genExercise();
    pExercise.textContent = exercise;
    window.currentResult = result; // Store the current result for checking
    inputResult.value = ''; // Clear previous answer
    inputResult.focus(); // Focus on input
}

btnCheck.addEventListener('click', () => {
    const userAnswer = parseInt(inputResult.value, 10);
    if (userAnswer === window.currentResult) {
        pFeedback.textContent = 'Correct!';
        score++;
    } else {
        pFeedback.textContent = 'Oops! Try again.';
    }
    pScore.textContent = `Score: ${score}`; // Update score display
    updateExercise(); // Generate a new exercise
});

// Initialize the game
updateExercise();
